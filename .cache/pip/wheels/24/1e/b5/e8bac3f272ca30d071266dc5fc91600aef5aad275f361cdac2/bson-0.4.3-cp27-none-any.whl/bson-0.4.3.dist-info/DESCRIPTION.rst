Independent BSON codec for Python that doesn't depend on MongoDB.


